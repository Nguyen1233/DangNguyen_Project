/*
 * micro.c
 *
 * Micro-specific definitions. Using the LPC1343 MicroController
 *
 * Created: 29th March, 2014
 *  Author: Embedded Laboratory
 * ========
*/
#include "micro.h"

// Right now there is nothing in this file.
